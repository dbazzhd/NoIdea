GLEW
----------------------------------------
Download GLEW src from the GLEW site.

Open build/vc12
Update the project, build all the files.
Copy all dlls to bin folder.
Copy all libs to lib folder.

Build and enjoy! 